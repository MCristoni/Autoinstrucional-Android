package br.fumec.sensorvalues;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SensorValuesActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float alpha = 0.9f,
            lastX, lastY, lastZ,
            lowPassX, lowPassY, lowPassZ,
            highPassX, highPassY, highPassZ,
            calibX, calibY, calibZ;

    private float zeroX = 0f, zeroY = 0f, zeroZ = 0f;

    private TextView xView, yView, zView,
            xLowPassView, yLowPassView, zLowPassView,
            xHighPassView, yHighPassView, zHighPassView,
            xCalibView, yCalibView, zCalibView;

    private long lastUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_values);

        xView = (TextView) findViewById(R.id.x_value_view);
        yView = (TextView) findViewById(R.id.y_value_view);
        zView = (TextView) findViewById(R.id.z_value_view);
        xLowPassView = (TextView) findViewById(R.id.x_lowpass_view);
        yLowPassView = (TextView) findViewById(R.id.y_lowpass_view);
        zLowPassView = (TextView) findViewById(R.id.z_lowpass_view);
        xHighPassView = (TextView) findViewById(R.id.x_highpass_view);
        yHighPassView = (TextView) findViewById(R.id.y_highpass_view);
        zHighPassView = (TextView) findViewById(R.id.z_highpass_view);
        xCalibView = (TextView) findViewById(R.id.x_calib_view);
        yCalibView = (TextView) findViewById(R.id.y_calib_view);
        zCalibView = (TextView) findViewById(R.id.z_calib_view);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        for (Sensor sensor : sensorManager.getSensorList(Sensor.TYPE_ALL)) {
            System.out.println(sensor.getName());
        }

        accelerometer = sensorManager
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        lastUpdate = System.currentTimeMillis();
    }


    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        sensorManager.unregisterListener(this);
        super.onPause();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            long actualTime = System.currentTimeMillis();
            if (actualTime - lastUpdate > 500) {
                lastUpdate = actualTime;

                float x = event.values[0], y = event.values[1], z = event.values[2];
                xView.setText(String.valueOf(x));
                yView.setText(String.valueOf(y));
                zView.setText(String.valueOf(z));

                lowPassX = lowPass(x, lowPassX);
                lowPassY = lowPass(y, lowPassY);
                lowPassZ = lowPass(z, lowPassZ);
                xLowPassView.setText(String.valueOf(lowPassX));
                yLowPassView.setText(String.valueOf(lowPassY));
                zLowPassView.setText(String.valueOf(lowPassZ));

                highPassX = highPass(x, lastX, highPassX);
                highPassY = highPass(y, lastY, highPassY);
                highPassZ = highPass(z, lastZ, highPassZ);
                xHighPassView.setText(String.valueOf(highPassX));
                yHighPassView.setText(String.valueOf(highPassY));
                zHighPassView.setText(String.valueOf(highPassZ));

                calibX = zeroX - x;
                calibY = zeroY - y;
                calibZ = zeroZ - z;
                xCalibView.setText(String.valueOf(calibX));
                yCalibView.setText(String.valueOf(calibY));
                zCalibView.setText(String.valueOf(calibZ));

                lastX = x;
                lastY = y;
                lastZ = z;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private float highPass(float current, float last, float filtered) {
        return alpha * (filtered + current - last);
    }

    private float lowPass(float current, float filtered) {
        return alpha * current + (1.0f - alpha) * filtered;
    }

    public void onCalib(View view) {
        zeroX = lastX;
        zeroY = lastY;
        zeroZ = lastZ;
        Toast.makeText(this,R.string.calibrated, Toast.LENGTH_SHORT).show();
    }

}
