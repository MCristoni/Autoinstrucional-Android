package br.fumec.servicojukebox;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class JukeboxActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jukebox);

        ListView list = (ListView) findViewById(R.id.song_list);
        list.setOnItemClickListener(this);
    }


    /*
     * Este método é chamado quando o botão de parar é clicado.
     * Ele inicia uma requisição para parar uma música.
     */
    public void onClickStop(View view) {
        Intent intent = new Intent(this, JukeboxService.class);
        intent.setAction(JukeboxService.ACTION_STOP);
        startService(intent);
    }

    /*
     * Este método é chamado quando o ListView é clicado.
     * Ele inicia uma requisição para tocar uma música.
     */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        String[] songTitles = getResources().getStringArray(R.array.song_titles);
        String title = songTitles[i].toLowerCase().replace(" ", "");

        Intent intent = new Intent(this, JukeboxService.class);
        intent.putExtra("title", title);
        intent.setAction(JukeboxService.ACTION_PLAY);
        startService(intent);
    }
}
