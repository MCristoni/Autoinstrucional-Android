package br.fumec.servicojukebox;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class JukeboxService extends Service {
    // Constantes para ações
    public static final String ACTION_PLAY = "play";
    public static final String ACTION_STOP = "stop";

    // Media player para executar as músicas
    private MediaPlayer player;

    /*
     * Este método é chamado a cada requisição que chega da atividade
     * via intent. Ele processa a requisição tocando ou parando
     * uma música.
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent.getAction();
        if (action.equals(ACTION_PLAY)) {
            // Converte o título em um ID de recurso
            String title = intent.getStringExtra("title");
            int id = getResources().getIdentifier(title, "raw", getPackageName());

            // pára qualquer música sendo executada
            if (player != null) {
                player.stop();
                player.release();
            }

            // executa a nova música
            player = MediaPlayer.create(this, id);
            player.setLooping(true);
            player.start();

        } else if (action.equals(ACTION_STOP)) {
            // pára qualquer música sendo executada
            if (player != null) {
                player.stop();
                player.release();
                player = null;
            }
        }

        return START_STICKY;   // START_STICKY: serviço continua rodando
    }

    // Esta aplicação não suporta binding
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
